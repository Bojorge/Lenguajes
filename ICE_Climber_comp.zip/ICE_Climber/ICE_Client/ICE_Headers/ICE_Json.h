//
// Created by gunther on 16/11/19.
//

#ifndef UNTITLED_ICE_JSON_H
#define UNTITLED_ICE_JSON_H

struct json_object * jsonParser(char jsonString[]);




#endif //UNTITLED_ICE_JSON_H
