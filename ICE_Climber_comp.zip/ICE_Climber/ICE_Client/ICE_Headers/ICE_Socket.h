//
// Created by gunther on 16/11/19.
//

#ifndef UNTITLED_ICE_SOCKET_H
#define UNTITLED_ICE_SOCKET_H


const char *initClient(char jsonString[]);


#endif //UNTITLED_ICE_SOCKET_H
