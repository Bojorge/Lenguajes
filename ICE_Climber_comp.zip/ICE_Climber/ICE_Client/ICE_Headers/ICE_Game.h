//
// Created by gunther on 16/11/19.
//

#ifndef UNTITLED_ICE_GAME_H
#define UNTITLED_ICE_GAME_H


int startGame();


#endif //UNTITLED_ICE_GAME_H
