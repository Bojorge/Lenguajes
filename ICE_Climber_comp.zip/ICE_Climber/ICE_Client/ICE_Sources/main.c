#include <stdio.h>
#include <stdbool.h>
#include <allegro5/bitmap.h>
#include <allegro5/allegro.h>
#include "../ICE_Headers/ICE_Game.h"



int main(int argc, char **argv) {
    startGame();


}